package main

import (
	"fmt"
)

// Fungsi rekursif untuk menemukan dan mencetak faktor bilangan dari N
func printFactors(n, i int) {
	// Jika nilai i lebih besar dari N, berhenti
	if i > n {
		return
	}
	// Jika N habis dibagi i, maka i adalah faktor dari N
	if n%i == 0 {
		fmt.Print(i, " ")
	}
	// Panggil fungsi printFactors dengan nilai i berikutnya
	printFactors(n, i+1)
}

func main() {
	var n int
	fmt.Print("Masukkan nilai N: ")
	fmt.Scan(&n)

	fmt.Print("Faktor dari ", n, " adalah: ")
	printFactors(n, 1) // Mulai dari faktor 1
	fmt.Println()
}

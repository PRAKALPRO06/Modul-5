package main

import (
	"fmt"
)

// Fungsi rekursif untuk mencetak bilangan dari N hingga 1
func printDescending(n int) {
	if n == 0 {
		return
	}
	fmt.Print(n, " ")
	printDescending(n - 1)
}

// Fungsi rekursif untuk mencetak bilangan dari 1 hingga N
func printAscending(n, current int) {
	if current > n {
		return
	}
	fmt.Print(current, " ")
	printAscending(n, current+1)
}

func main() {
	var n int
	fmt.Print("Masukkan nilai N: ")
	fmt.Scan(&n)

	// Cetak bilangan dari N ke 1
	printDescending(n)
	// Cetak bilangan dari 2 ke N untuk menghindari pengulangan angka 1 dua kali
	printAscending(n, 2)
	fmt.Println()
}

package main

import (
	"fmt"
)

// Fungsi rekursif untuk menghitung x pangkat y
func power(x, y int) int {
	// Base case: jika y == 0, hasilnya adalah 1
	if y == 0 {
		return 1
	}
	// Panggil rekursif untuk menghitung x^(y-1) dan kalikan dengan x
	return x * power(x, y-1)
}

func main() {
	var x, y int
	fmt.Print("Masukkan nilai x dan y (x^y): ")
	fmt.Scan(&x, &y)

	result := power(x, y)
	fmt.Printf("Hasil dari %d pangkat %d adalah: %d\n", x, y, result)
}

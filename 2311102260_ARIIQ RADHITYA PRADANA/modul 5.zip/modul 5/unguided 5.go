package main

import (
	"fmt"
)

// Fungsi rekursif untuk mencetak bilangan ganjil dari 1 hingga N
func printOdd(n, current int) {
	// Jika nilai current lebih besar dari N, berhenti
	if current > n {
		return
	}
	// Cetak nilai current karena ganjil
	fmt.Print(current, " ")
	// Panggil rekursi dengan current ditambah 2 untuk tetap ke bilangan ganjil
	printOdd(n, current+2)
}

func main() {
	var n int
	fmt.Print("Masukkan nilai N: ")
	fmt.Scan(&n)

	fmt.Print("Bilangan ganjil dari 1 hingga ", n, " adalah: ")
	printOdd(n, 1) // Mulai dari bilangan ganjil pertama, yaitu 1
	fmt.Println()
}

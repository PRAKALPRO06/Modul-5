package main

import "fmt"

// Fungi untuk mencetak bilangan dari n hingga 1
func cetakMundur(n int) {
	if n == 1 {
		fmt.Println(n)
		return
	}
	fmt.Print(n, " ")
	cetakMundur(n - 1)
}

func main() {
	var n int
	fmt.Print(" Masukkan nilai n untuk cetak bilangan dari n hingga 1: ")
	fmt.Scanln(&n)
	fmt.Print(" hasil cetak mundur: ")
	cetakMundur(n)
}
